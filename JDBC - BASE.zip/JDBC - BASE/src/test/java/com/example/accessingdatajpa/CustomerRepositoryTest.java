package com.example.accessingdatajpa;


import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.batch.BatchProperties;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CustomerRepositoryTest {
	@Autowired
	private JDBCCustomerRepository customerRepository;

	@Test
	void testRepo() {
		Customer customer = new Customer();
		customer.setFirstName("Jck");
		customer.setLastName("Ryan");

		// Creating a Customer
		customer = customerRepository.save(customer);


	}
}
